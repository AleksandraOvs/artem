<section class="about-company">
    <div class="content-wrapper">
        <h3 class="h3-heading">О компании</h3>

        <div class="about-company__section">
            <div class="about-company__section__contacts">

                <div class="about-company__section__contacts__phone">

                    <h4 class="h4-heading">Телефон:</h4>
                    <a href="tel:00110011" class="about-company__section__contacts__phone__link">8 (900) 852-55-55</a>
                </div>

                <div class="about-company__section__contacts__address">
                    <h4 class="h4-heading">Адрес:</h4>
                    <p>8 (900) 852-55-55</p>
                </div>
            </div>
            <div class="about-company__section__map"><iframe src="https://yandex.ru/map-widget/v1/?um=constructor%3A439d7b9b6526a27ab48d500b82d8803c398fe5825fd29b90375810766ea7dc00&amp;source=constructor" width="100%" height="400" frameborder="0"></iframe></div>
        </div>

    </div>
</section>
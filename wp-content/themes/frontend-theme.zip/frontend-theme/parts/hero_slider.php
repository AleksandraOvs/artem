<div class="content-wrapper">
   <div class="swiper-container hero-slider__container">
      <div class="swiper-wrapper hero-slider__wrapper">
        <div class="swiper-slide hero-slider__slide">
          <img src="<?php echo get_template_directory_uri();?>../assets/img/slide1.jpg" alt="">
        </div>
        <div class="swiper-slide hero-slider__slide">
          <img src="<?php echo get_template_directory_uri();?>../assets/img/slide2.jpg" alt="">
        </div>
      </div>

      <div class="swiper-pagination hero-slider__pagination"></div>
    <div class="content-wrapper">
     <section class="first-block">
        <h2 class="first-block-heading">Реализация и&nbsp;доставка песка и&nbsp;щебня в&nbsp;Приморском крае</h2>
        <p class="first-block-description">Есть над чем задуматься: базовые сценарии поведения пользователей и по сей
        день остаются уделом проектантов</p>
        <button type="button" class="order-calc fill-button" aria-label="Заказать расчет">Скачать прайс</button>
      </section>
</div>
  </div> 
</div>
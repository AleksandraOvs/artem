<section class="product-slider">
    <div class="content-wrapper">
        <h3 class="h3-heading">Фото и характеристики продукции</h3>
        <div class="swiper-container product-slider__container">
            <div class="swiper-wrapper product-slider__wrapper">
                <div class="swiper-slide product-slider__slide">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/13.jpg" alt="">
                    <div class="product-slider__slide__content__sign">
                        <p>Щебень скальный&nbsp;АБ, фр.&nbsp;80&nbsp;х&nbsp;120</p>
                    </div>
                </div>
                <div class="swiper-slide product-slider__slide">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/14.jpg" alt="">
                    <div class="product-slider__slide__content__sign">
                        <p>Щебень скальный&nbsp;АБ, фр.&nbsp;80&nbsp;х&nbsp;120</p>
                    </div>
                </div>
                <div class="swiper-slide product-slider__slide">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/15.jpg" alt="">
                    <div class="product-slider__slide__content__sign">
                        <p>Щебень скальный&nbsp;АБ, фр.&nbsp;80&nbsp;х&nbsp;120</p>
                    </div>
                </div>
                <div class="swiper-slide product-slider__slide">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/17.jpg" alt="">
                    <div class="product-slider__slide__content__sign">
                        <p>Щебень скальный&nbsp;АБ, фр.&nbsp;80&nbsp;х&nbsp;120</p>
                    </div>
                </div>
                <div class="swiper-slide product-slider__slide">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/18.jpg" alt="">
                    <div class="product-slider__slide__content__sign">
                        <p>Щебень скальный&nbsp;АБ, фр.&nbsp;80&nbsp;х&nbsp;120</p>
                    </div>
                </div>
                <div class="swiper-slide product-slider__slide">
                    <img src="<?php echo get_template_directory_uri();?>/assets/img/19.jpg" alt="">
                    <div class="product-slider__slide__content__sign">
                        <p>Щебень скальный&nbsp;АБ, фр.&nbsp;80&nbsp;х&nbsp;120</p>
                    </div>
                </div>
            </div>
            
            <ul class="product-slider__slide__nav">
                <li class="product-slider__slide__nav__button-prev"></li>
                <li class="product-slider__slide__nav__button-next"></li>
            </ul>
        </div>
    </div>
</section>
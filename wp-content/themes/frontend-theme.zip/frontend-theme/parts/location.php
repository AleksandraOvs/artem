<section class="location">
    <div class="content-wrapper">
    <div class="location__content">    
    <div class="about-us-more-img">
        <div class="about-us-blur-block">
            <p class="about-us-blur-block-text">Принимая во внимание показатели успешности, перспективное планирование
              способствует подготовке и реализации новых принципов.</p>
        </div>
    </div>

    <ul class="about-us-more-list">
        <li class="more-item">
            <div class="more-item-text"><span class="first-line-span">Консультация с широким активом,</span>
              <p class="more-item-paragraph">а также свежий взгляд на привычные вещи - безусловно открывает новые
                горизонты для как самодостаточных, так и внешне зависимых концептуальных решений.</p>
            </div>
        </li>

        <li class="more-item">
            <div class="more-item-text"><span class="first-line-span">В своём стремлении повысить</span>
              <p class="more-item-paragraph">качество жизни, они забывают, что сплочённость команды профессионалов
                представляет собой интересный эксперимент проверки прогресса профессионального сообщества. </p>
            </div>
        </li>
    </ul>
</div>
</div>
</section>
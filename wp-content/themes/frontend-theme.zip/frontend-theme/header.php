<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
  
  <?php wp_head() ?>
</head>



<body>
    <header class="header">
    <div class="content-wrapper header-container">
      <button id="burger" class="burger"></button>
      
       <?php the_custom_logo(); ?>
    
        <?php 
if( has_nav_menu( 'head_menu' )) {
wp_nav_menu( array(
  'theme_location' => 'head_menu',
  'container' => false,
  'menu_class' => 'nav navbar-nav',
  'items_wrap' => '<ul class="%2$s">%3$s</ul>',
  'depth' => 2,
  'walker' => new Main_walker_menu()
));
}
?>
    </div>
  </header>
